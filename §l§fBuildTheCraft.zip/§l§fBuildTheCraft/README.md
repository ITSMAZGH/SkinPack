<div align="center">
<img src="https://i.ibb.co/zh4DWw9/icon.jpg" alt="SELF-HXs" width="300" />

# MyMans APIs

>
>
>
</div>
<p align="center">
  <a href="https://github.com/ITSMAZGH"><img title="Author" src="https://img.shields.io/badge/Author-ITSMAZGH-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://wa.me/6288224859350">BuildTheCraft >//< </a>
</h4>
</p>

## CARA INSTALL DI TERMUX
```bash
> pkg install nodejs && pkg install git
> termux-setup-storage
> git clone https://github.com/ITSMAZGH/SkinPack
> cd SkinPack && cp -r §l§fBuildTheCraft.zip /$HOME/storage/shared/games/com.mojang/skin_packs
```

# LIST SKIN

| 4 | BOY |
| ------------- | ------------- |
| 2 | GIRL |

  # MAKASIH
* [`BuildTheCraft`](https://youtube.com/c/BuildTheCraft)